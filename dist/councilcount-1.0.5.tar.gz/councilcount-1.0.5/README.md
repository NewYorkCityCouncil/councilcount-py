# Installation

To install `councilcount` for Python, please use the following code:

Use pip to install the package in the terminal:
``` bash
pip install councilcount
```
Then import the package in Python:
``` python
import councilcount as cc
```

# Prerequisites

- Python version 3.9 or above is needed.
